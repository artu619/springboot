package com.ejemplo.coches;

public class Coche implements Comparable<Coche> {
    private String matricula;
    private String marca;
    private String modelo;
    private int kilometros;

    public Coche(String matricula, String marca, String modelo, int kilometros) {
        if (matricula.length() < 10) {
            throw new IllegalArgumentException("La matrícula debe tener al menos 10 caracteres.");
        }
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
        this.kilometros = kilometros;
    }

    public String getMatricula() {
        return matricula;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public int getKilometros() {
        return kilometros;
    }

    @Override
    public String toString() {
        return "Matrícula: " + matricula + ", Marca: " + marca + ", Modelo: " + modelo + ", Km: " + kilometros;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Coche)) return false;
        Coche coche = (Coche) o;
        return matricula.equals(coche.matricula);
    }

    @Override
    public int hashCode() {
        return matricula.hashCode();
    }

    @Override
    public int compareTo(Coche otro) {
        return this.matricula.compareTo(otro.matricula);
    }
}
