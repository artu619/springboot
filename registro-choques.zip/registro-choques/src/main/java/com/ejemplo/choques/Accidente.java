package com.ejemplo.choques;

import java.time.LocalDate;

public class Accidente {
    private LocalDate fecha;
    private String ubicacion;
    private String descripcion;

    public Accidente(LocalDate fecha, String ubicacion, String descripcion) {
        this.fecha = fecha;
        this.ubicacion = ubicacion;
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return "Fecha: " + fecha + ", Ubicación: " + ubicacion + ", Descripción: " + descripcion;
    }
}
