package com.ejemplo.coches;

import java.util.Comparator;

public class ComparadorMarca implements Comparator<Coche> {
    @Override
    public int compare(Coche c1, Coche c2) {
        return c1.getMarca().compareTo(c2.getMarca());
    }
}
