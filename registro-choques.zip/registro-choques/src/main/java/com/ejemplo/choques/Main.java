package com.ejemplo.choques;

import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        RegistroAccidentes registro = new RegistroAccidentes();

        registro.agregarAccidente(new Accidente(LocalDate.now(), "Calle Mayor", "Colisión leve entre dos vehículos."));
        registro.mostrarAccidentes();
    }
}
