package com.ejemplo.coches;

import java.util.*;

public class Main {
    private static Set<Coche> coches = new HashSet<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("\n1. Añadir coche");
            System.out.println("2. Listar coches");
            System.out.println("3. Listar por matrícula (orden natural)");
            System.out.println("4. Listar por marca");
            System.out.println("0. Salir");
            System.out.print("Selecciona una opción: ");
            opcion = Integer.parseInt(scanner.nextLine());

            switch (opcion) {
                case 1:
                    añadirCoche();
                    break;
                case 2:
                    listarCoches(coches);
                    break;
                case 3:
                    List<Coche> listaMatricula = new ArrayList<>(coches);
                    Collections.sort(listaMatricula);
                    listarCoches(listaMatricula);
                    break;
                case 4:
                    List<Coche> listaMarca = new ArrayList<>(coches);
                    listaMarca.sort(new ComparadorMarca());
                    listarCoches(listaMarca);
                    break;
                case 0:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        } while (opcion != 0);
    }

    private static void añadirCoche() {
        try {
            System.out.print("Matrícula: ");
            String matricula = scanner.nextLine();
            System.out.print("Marca: ");
            String marca = scanner.nextLine();
            System.out.print("Modelo: ");
            String modelo = scanner.nextLine();
            System.out.print("Kilómetros: ");
            int km = Integer.parseInt(scanner.nextLine());

            Coche nuevo = new Coche(matricula, marca, modelo, km);
            if (coches.add(nuevo)) {
                System.out.println("Coche añadido.");
            } else {
                System.out.println("Ya existe un coche con esa matrícula.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void listarCoches(Collection<Coche> lista) {
        if (lista.isEmpty()) {
            System.out.println("No hay coches registrados.");
        } else {
            for (Coche c : lista) {
                System.out.println(c);
            }
        }
    }
}
