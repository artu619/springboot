package com.ejemplo.choques;

import java.util.ArrayList;
import java.util.List;

public class RegistroAccidentes {
    private List<Accidente> lista = new ArrayList<>();

    public void agregarAccidente(Accidente accidente) {
        lista.add(accidente);
    }

    public void mostrarAccidentes() {
        for (Accidente acc : lista) {
            System.out.println(acc);
        }
    }
}
